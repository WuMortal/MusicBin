import { createApp } from 'vue'
import { invoke } from '@tauri-apps/api/core'
import App from './App.vue'
import router from './router'
import { initTheme } from './composables/useTheme'
import './styles/tokens.css'
import './styles/global.css'

// F12 打开开发者工具（release 包也生效，方便排查线上问题）
window.addEventListener('keydown', (e) => {
  if (e.key === 'F12') {
    e.preventDefault()
    void invoke('open_devtools').catch(() => { /* 非 Tauri 环境忽略 */ })
  }
})

initTheme()
createApp(App).use(router).mount('#app')
